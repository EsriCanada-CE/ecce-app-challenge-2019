// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"\ubca0\uc774\uc2a4\ub9f5 \uac24\ub7ec\ub9ac",chooseWebScene:"\uc6f9 \uc52c \uc120\ud0dd",chooseWebMap:"\uc6f9 \ub9f5 \uc120\ud0dd",_localized:{}}});