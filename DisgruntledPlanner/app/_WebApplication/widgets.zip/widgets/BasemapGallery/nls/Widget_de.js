// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"Grundkarten-Galerie",chooseWebScene:"Webszene ausw\u00e4hlen",chooseWebMap:"Webkarte ausw\u00e4hlen",_localized:{}}});