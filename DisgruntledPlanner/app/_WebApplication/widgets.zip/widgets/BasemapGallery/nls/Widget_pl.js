// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"Galeria map bazowych",chooseWebScene:"Wybierz scen\u0119 internetow\u0105",chooseWebMap:"Wybierz map\u0119 internetow\u0105",_localized:{}}});