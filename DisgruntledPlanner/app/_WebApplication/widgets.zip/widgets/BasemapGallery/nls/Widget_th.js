// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"\u0e41\u0e01\u0e25\u0e40\u0e25\u0e2d\u0e23\u0e35\u0e48\u0e41\u0e1c\u0e19\u0e17\u0e35\u0e48\u0e10\u0e32\u0e19",chooseWebScene:"\u0e40\u0e25\u0e37\u0e2d\u0e01\u0e40\u0e27\u0e1a\u0e0b\u0e35\u0e19",chooseWebMap:"\u0e40\u0e25\u0e37\u0e2d\u0e01\u0e40\u0e27\u0e47\u0e1a\u0e41\u0e1c\u0e19\u0e17\u0e35\u0e48",_localized:{}}});