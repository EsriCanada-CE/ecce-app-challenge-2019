// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"B\u1ed9 s\u01b0u t\u1eadp b\u1ea3n \u0111\u1ed3 n\u1ec1n",chooseWebScene:"Ch\u1ecdn web scene",chooseWebMap:"Ch\u1ecdn b\u1ea3n \u0111\u1ed3 web",_localized:{}}});