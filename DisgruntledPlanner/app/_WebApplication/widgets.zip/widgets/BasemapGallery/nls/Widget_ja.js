// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"\u30d9\u30fc\u30b9\u30de\u30c3\u30d7 \u30ae\u30e3\u30e9\u30ea\u30fc",chooseWebScene:"Web \u30b7\u30fc\u30f3\u306e\u9078\u629e",chooseWebMap:"Web \u30de\u30c3\u30d7\u306e\u9078\u629e",_localized:{}}});