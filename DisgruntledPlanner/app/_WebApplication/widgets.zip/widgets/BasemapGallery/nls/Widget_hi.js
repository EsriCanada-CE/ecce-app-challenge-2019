// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"Basemap \u0917\u0948\u0932\u0930\u0940",chooseWebScene:"\u0935\u0947\u092c \u0926\u0943\u0936\u094d\u092f \u091a\u0941\u0928\u0947\u0902",chooseWebMap:"\u0935\u0947\u092c \u092e\u0948\u092a \u091a\u0941\u0928\u0947\u0902",_localized:{}}});