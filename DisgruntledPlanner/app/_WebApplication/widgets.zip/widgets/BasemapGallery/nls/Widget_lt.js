// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"Pagrindo \u017eem\u0117lapiai",chooseWebScene:"Pasirinkite internetin\u0119 scen\u0105",chooseWebMap:"Pasirinkite internetin\u012f \u017eem\u0117lap\u012f",_localized:{}}});