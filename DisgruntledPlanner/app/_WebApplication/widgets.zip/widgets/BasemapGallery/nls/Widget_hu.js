// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"Alapt\u00e9rk\u00e9p-gal\u00e9ria",chooseWebScene:"V\u00e1lasszon web 3D t\u00e9rk\u00e9pet",chooseWebMap:"V\u00e1lasszon webt\u00e9rk\u00e9pet",_localized:{}}});