// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"Biblioth\u00e8que de fonds de carte",chooseWebScene:"Choisir la sc\u00e8ne web",chooseWebMap:"Choisir la carte web",_localized:{}}});