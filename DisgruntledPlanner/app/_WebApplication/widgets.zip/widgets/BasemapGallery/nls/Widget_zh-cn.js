// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/BasemapGallery/nls/strings":{_widgetLabel:"\u5e95\u56fe\u5e93",chooseWebScene:"\u9009\u62e9 Web \u573a\u666f",chooseWebMap:"\u9009\u62e9 Web \u5730\u56fe",_localized:{}}});