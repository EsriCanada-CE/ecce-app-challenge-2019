// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/About/nls/strings":{productVersion:"\u0625\u0635\u062f\u0627\u0631 \u0627\u0644\u0645\u0646\u062a\u062c: ",kernelVersion:"\u0625\u0635\u062f\u0627\u0631 Kernel: ",_widgetLabel:"\u0646\u0628\u0630\u0629 \u0639\u0646",_localized:{}}});