// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/About/nls/strings":{productVersion:"\u0388\u03ba\u03b4\u03bf\u03c3\u03b7 \u03c0\u03c1\u03bf\u03ca\u03cc\u03bd\u03c4\u03bf\u03c2: ",kernelVersion:"\u0388\u03ba\u03b4\u03bf\u03c3\u03b7 \u03c0\u03c5\u03c1\u03ae\u03bd\u03b1: ",_widgetLabel:"\u03a0\u03bb\u03b7\u03c1\u03bf\u03c6\u03bf\u03c1\u03af\u03b5\u03c2",_localized:{}}});