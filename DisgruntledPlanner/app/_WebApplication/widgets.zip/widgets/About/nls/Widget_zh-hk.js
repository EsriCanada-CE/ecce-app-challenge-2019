// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/About/nls/strings":{productVersion:"\u7522\u54c1\u7248\u672c: ",kernelVersion:"\u6838\u5fc3\u7248\u672c: ",_widgetLabel:"\u95dc\u65bc",_localized:{}}});