// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/About/nls/strings":{productVersion:"\u0909\u0924\u094d\u092a\u093e\u0926 \u0938\u0902\u0938\u094d\u0915\u0930\u0923: ",kernelVersion:"\u0915\u0930\u094d\u0928\u0947\u0932 \u0938\u0902\u0938\u094d\u0915\u0930\u0923: ",_widgetLabel:"\u092c\u093e\u0930\u0947 \u092e\u0947\u0902",_localized:{}}});