// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/About/nls/strings":{productVersion:"Verze produktu: ",kernelVersion:"Verze j\u00e1dra: ",_widgetLabel:"O aplikaci",_localized:{}}});