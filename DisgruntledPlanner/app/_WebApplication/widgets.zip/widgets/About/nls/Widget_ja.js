// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/About/nls/strings":{productVersion:"\u88fd\u54c1\u30d0\u30fc\u30b8\u30e7\u30f3: ",kernelVersion:"\u30ab\u30fc\u30cd\u30eb \u30d0\u30fc\u30b8\u30e7\u30f3: ",_widgetLabel:"\u60c5\u5831",_localized:{}}});