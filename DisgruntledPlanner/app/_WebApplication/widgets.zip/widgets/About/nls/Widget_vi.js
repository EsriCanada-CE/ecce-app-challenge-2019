// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/About/nls/strings":{productVersion:"Phi\u00ean b\u1ea3n s\u1ea3n ph\u1ea9m: ",kernelVersion:"Phi\u00ean b\u1ea3n Kernel: ",_widgetLabel:"V\u1ec1",_localized:{}}});