// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/About/nls/strings":{productVersion:"\u0412\u0435\u0440\u0441\u0438\u044f \u043f\u0440\u043e\u0434\u0443\u043a\u0442\u0430: ",kernelVersion:"\u0412\u0435\u0440\u0441\u0438\u044f \u044f\u0434\u0440\u0430: ",_widgetLabel:"\u041e\u043f\u0438\u0441\u0430\u043d\u0438\u0435",_localized:{}}});