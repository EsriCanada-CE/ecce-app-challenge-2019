// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/About/nls/strings":{productVersion:"Term\u00e9kverzi\u00f3: ",kernelVersion:"Kernelverzi\u00f3: ",_widgetLabel:"Tov\u00e1bbi inform\u00e1ci\u00f3",_localized:{}}});