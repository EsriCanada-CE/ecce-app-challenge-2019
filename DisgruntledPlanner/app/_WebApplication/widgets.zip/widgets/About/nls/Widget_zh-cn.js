// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/About/nls/strings":{productVersion:"\u4ea7\u54c1\u7248\u672c\uff1a ",kernelVersion:"\u6838\u7248\u672c\uff1a ",_widgetLabel:"\u5173\u4e8e",_localized:{}}});