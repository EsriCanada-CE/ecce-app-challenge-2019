// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/AddData/setting/nls/strings":{numPerPage:"Number of items per page",scopeOptions:{defaultScope:"Default search scope",labelPlaceholder:"Optional label",MyContent:"Allow My Content",MyOrganization:"Allow My Organization",ArcGISOnline:"Allow ArcGIS Online",Curated:"Allow Curated",CuratedFilter:"Curated filter",livingAtlasExample:"Living atlas example:"},addFromUrl:{caption:"Allow URL"},addFromFile:{caption:"Allow File",maxRecordCount:"Maximum records per file"},_default:"Default",makeDefault:"Make default",
_localized:{}}});