// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define(["dojo/_base/declare","dojo/_base/lang"],function(a,b){return a(null,{allowArcGISOnline:!0,arcgisOnlinePortal:null,orgId:null,portal:null,username:null,constructor:function(a){b.mixin(this,a)}})});